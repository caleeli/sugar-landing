<?php

namespace App\FRest;

/**
 * Description of Productos
 *
 * @author davidcallizaya
 */
class Productos extends FRest
{
    protected $path = '/products';
    protected $method = 'GET';
    protected $sample = [];

}
